%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Fachvertiefung AUT Übung 4
% Zeitparametrierung
% Eingänge: t           = Zeit
%           par.T       = Endzeitpunkt der Zeitparametrierung
%
% Ausgänge: s           = Position am Pfad
%           s_p         = Geschwindigkeit am Pfad
%           s_pp        = Beschleunigung am Pfad
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [s, s_p, s_pp] = Zeitparametrierung(t, par)
  T=par.T;

  s=0;
  s_p=0;
  s_pp=0;
end
