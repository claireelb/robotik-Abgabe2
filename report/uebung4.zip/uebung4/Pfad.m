%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Fachvertiefung AUT �bung 4
% Trajektoriengenerierung Hypotrochoid
% Eing�nge: s           = Pfadposition s aus [0, 2 pi]
%           par.R       = Radius Au�enkreis
%           par.r       = Radius Innenkreis
%           par.d       = Abstand Mittelpunk Innenkreis zum Abrollpfad
%
% Ausg�nge: x           = Pfadpunkt an der Position s
%           x_s         = 1. Ableitung des Pfades an der Position s
%           x_ss        = 2. Ableitung des Pfades an der Position s
%
% Autoren: RL, TW 16.02.2021
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [x, x_s, x_ss] = Pfad(s, par)
  % Eing�nge und Parameter
  R = par.R;
  r = par.r;
  d = par.d;


  % Ausg�nge
  x = zeros(3,1);
  x_s = zeros(3,1);
  x_ss = zeros(3,1);
end
