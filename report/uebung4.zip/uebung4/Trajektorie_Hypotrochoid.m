%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Fachvertiefung AUT �bung 4
% Trajektorienplanung Hypotrochoid
% Eing�nge: theta_vec   = 3xN Zeitparametrierung des Winkels und Ableitungen
%           par.R       = Radius Au�enkreis
%           par.r       = Radius Innenkreis
%           par.d       = Abstand Mittelpunk Innenkreis zum Abrollpfad
%
% Ausg�nge: x_t         = 6xN Pose der gew�nschte Trajekorie
%           x_t_p       = 6xN 1. Ableitung der Pose der gew�nschte Trajekorie
%           x_t_pp      = 6xN 2. Ableitung der Pose der gew�nschte Trajekorie
%
% Autoren: 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [x_t, x_t_p, x_t_pp] = Trajektorie_Hypotrochoid(theta_vec, par)

x_t = zeros(6,size(theta_vec,2));
x_t_p = x_t;
x_t_pp = x_t;

end
