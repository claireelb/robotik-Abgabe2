%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Fachvertiefung AUT �bung 4
% Parameterdatei
%
% Autor: RL, TW 16.02.2021
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear

%% Laden der allgemeinen Parameter

% Zeitparameter
par.T = 25;             % Simulationszeit
t = (0:5e-3:par.T)';    % Zeitvektor

% Laden der Parameter
addpath('./helper')
addpath('./iiwa')
run('iiwa_parameters_stud');
run('Visualisierung_Parameter');

%% Parameter Trajektorie
par.H_0_w = eye(4);

% Hypotrochoid
par.R = 0;
par.r = 0;
par.d = 0;

% Zeitparametrierung des Pfades
p=zeros(3,length(t));
for i=1:length(t)
  s = Zeitparametrierung(t(i), par);
  x = Pfad(s, par);
  % Trajektorie p(t)=x(s(t))
  p(:,i) = x;
end

% Anfangswerte und Visualisierung der Trajektorie
[q_0, q_0_p, q_0_pp, par] = Visualisierung_Trajektorie(t, p, par, param_robot);

%% Inverse Kinematik
parreg.nr.k_0 = [0];
parreg.ik.K_0 = [0];
parreg.ik.K_1 = [0];

%% Kaskadierte Regelung
% I-Geschwindigkeits-Zustandsregler
parreg.kr.kx_gr=[0];
parreg.kr.ki_gr=[0];

% Pole Placement Positionsregler
parreg.kr.kp_pr = [0];
parreg.kr.ki_pr = [0];

%% PD-Regelung
parreg.pd.kd = [0];
parreg.pd.kp = [0];

%% CT-Regelung
parreg.ct.kp = [0];
parreg.ct.kd = [0];
